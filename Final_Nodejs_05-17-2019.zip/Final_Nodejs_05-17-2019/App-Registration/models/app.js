const Joi = require('joi');
const mongoose = require('mongoose');
const App = mongoose.model('App', new mongoose.Schema({
    app_name: {
        type: String,
        required: true,
        minlength: 5,
        maxlength: 50
    },

}));
function validateApp(app) {
    const schema = {
        app_name: Joi.string().min(5).max(50).required(),
    };
    return Joi.validate(app, schema);
}
exports.App = App;
exports.validate = validateApp;
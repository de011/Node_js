// Separate to easily edit or manage the config

module.exports = {
  db: 'mongodb://localhost:27017/mydb',
  secret: 'secrectkey'
};

